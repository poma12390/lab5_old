package lab5.runners;

public enum Position {
    DIRECTOR,
    MANAGER,
    LABORER,
    ENGINEER,
    BAKER;
}
