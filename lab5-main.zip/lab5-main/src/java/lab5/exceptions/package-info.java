/**
 * package with different kinds of exceptions
 * @see lab5.exceptions.InvalidDataException
 * @see lab5.exceptions.CommandException
 * @see lab5.exceptions.FileException
 */
package lab5.exceptions;