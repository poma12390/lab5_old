package lab5.exceptions;

public class EndStreamException extends RuntimeException {
    public EndStreamException() {
    }
}
