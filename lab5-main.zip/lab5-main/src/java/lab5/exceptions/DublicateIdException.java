package lab5.exceptions;

public class DublicateIdException extends InvalidDataException{
    public DublicateIdException() {
        super("Dublicate id");
    }
}
